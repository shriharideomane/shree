import android.content.Context
import android.util.Log
import com.example.common.EventTracker
import com.squareup.picasso.Picasso

class Plugin() : EventTracker {
    override fun inti(context: Context) {
        super.inti(context)
        Log.d("uk", "Initialised")
        Picasso.get().load("https://media.geeksforgeeks.org/wp-content/cdn-uploads/logo-new-2.svg")
    }

    override fun trackView(map: String) {
        super.trackView(map)
        Log.d("trackView", map)
    }

    override fun trackEvent(map: String) {
        super.trackEvent(map)
        Log.d("trackEvent", map)
    }

}