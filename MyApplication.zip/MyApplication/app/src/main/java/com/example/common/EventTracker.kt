package com.example.common

import android.content.Context

interface EventTracker{
    fun inti(context: Context) {}
    fun trackView(map : String) {}
    fun trackEvent(map : String) {}
}