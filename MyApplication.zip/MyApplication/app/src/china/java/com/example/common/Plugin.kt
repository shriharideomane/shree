import android.content.Context
import android.util.Log
import com.bumptech.glide.Glide
import com.example.common.EventTracker

class Plugin() : EventTracker {
    override fun inti(context: Context) {
        super.inti(context)
        Log.d("china", "Initialised")
        Glide.with(context).load("https://goo.gl/gEgYUd")
    }

    override fun trackView(map: String) {
        super.trackView(map)
        Log.d("trackView", map)
    }

    override fun trackEvent(map: String) {
        super.trackEvent(map)
        Log.d("trackEvent", map)
    }

}